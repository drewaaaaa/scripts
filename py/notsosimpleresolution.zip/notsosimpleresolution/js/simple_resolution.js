import { app } from "../../scripts/app.js";

const STEP = 64; // должен совпадать со step в INPUT_TYPES

app.registerExtension({
  name: "not_so_simple_resolution.label",
  nodeCreated(node) {
    if (node.comfyClass !== "NotSoSimpleResolutionNode") return;

    const get = (name) => node.widgets.find((w) => w.name === name);
    const ww = get("width");
    const wh = get("height");
    const sw = get("swap");
    const lock = get("lock_ratio");

    const label = node.addWidget("text", "resolution", "", () => {}, { serialize: false });
    label.disabled = true;

    let ratio = ww.value / wh.value;

    const snap = (v, wd) =>
      Math.min(wd.options.max, Math.max(wd.options.min, Math.round(v / STEP) * STEP));

    const update = () => {
      const [w, h] = sw.value ? [wh.value, ww.value] : [ww.value, wh.value];
      label.value = `${w} × ${h}`;
      node.setDirtyCanvas(true, true);
    };

    const hook = (wd, fn) => {
      const prev = wd.callback;
      wd.callback = function (...args) {
        prev?.apply(this, args);
        fn();
        update();
      };
    };

    hook(ww, () => { if (lock.value) wh.value = snap(ww.value / ratio, wh); });
    hook(wh, () => { if (lock.value) ww.value = snap(wh.value * ratio, ww); });
    hook(lock, () => { if (lock.value) ratio = ww.value / wh.value; });
    hook(sw, () => {});

    const onConfigure = node.onConfigure;
    node.onConfigure = function (...args) {
      onConfigure?.apply(this, args);
      ratio = ww.value / wh.value;
      update();
    };

    update();
  },
});