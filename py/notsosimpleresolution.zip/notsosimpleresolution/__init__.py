class NotSoSimpleResolutionNode:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "width": ("INT", {"default": 1024, "min": 64, "max": 8192, "step": 64}),
                "height": ("INT", {"default": 1024, "min": 64, "max": 8192, "step": 64}),
                "swap": ("BOOLEAN", {"default": False, "tooltip": "Поменять местами ширину и высоту"}),
                "lock_ratio": ("BOOLEAN", {"default": False, "tooltip": "Сохранять соотношение сторон при изменении ширины или высоты"}),
            }
        }

    RETURN_TYPES = ("INT", "INT")
    RETURN_NAMES = ("width", "height")
    FUNCTION = "calculate"
    CATEGORY = "utilities"

    def calculate(self, width, height, swap, lock_ratio):
        if swap:
            width, height = height, width
        return (width, height)

WEB_DIRECTORY = "./js"
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]

NODE_CLASS_MAPPINGS = {
    "NotSoSimpleResolutionNode": NotSoSimpleResolutionNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "NotSoSimpleResolutionNode": "Not So Simple Resolution"
}